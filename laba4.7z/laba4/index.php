<?php
//1
//$file = 'hello.txt';
//$current = "Hello World!\n";
//file_put_contents($file,$current,FILE_APPEND|LOCK_EX);
//$command = file_get_contents('hello.txt');
//echo $command;
//2
//$dat = date("Y-m-j-H-i-s");
//echo $dat;
//3
function getItems($arr, $filename){
    foreach ($arr as $key => $item) {
        $val =  $key . ' => ' . $item . "\n";
        file_put_contents($filename, $val, FILE_APPEND);
    }
}
getItems(get_loaded_extensions(), 'extensions.txt');
getItems(get_defined_constants(), 'constants.txt');
?>